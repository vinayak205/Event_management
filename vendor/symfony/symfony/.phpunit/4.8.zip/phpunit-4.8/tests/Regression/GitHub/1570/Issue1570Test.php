<?php
class Issue1570Test extends PHPUnit_Framework_TestCase
{
    public function testOne()
    {
        print '*';
    }
}
